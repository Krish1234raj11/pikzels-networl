
document.getElementById("server-status").innerText = "✅ Pikzels Network is Online with 37 players!";
